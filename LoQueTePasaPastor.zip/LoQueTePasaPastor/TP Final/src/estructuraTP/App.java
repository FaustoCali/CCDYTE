package estructuraTP;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class App {
	public static Connection conn = null; 
	public static void Conectar() {
		String url = "jdbc:mysql://localhost:3306/esotilin";
		String usuario = "root";
		String contrasenia = "admin";
		
		try {
			// 1.
			conn = DriverManager.getConnection(url, usuario, contrasenia);
			// 2.

			if (conn != null) {
				System.out.println("Conexi�n exitosa.");
			}
			
		} catch (SQLException e) {
			System.out.println("No pudo establecerse la conexi�n.");
			e.printStackTrace();
		}
	}
	

}
