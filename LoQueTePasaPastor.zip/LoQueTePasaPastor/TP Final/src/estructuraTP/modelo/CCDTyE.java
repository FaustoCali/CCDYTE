package estructuraTP.modelo;

import java.sql.Date;

public class CCDTyE {
	private int IDCCDTyE;
	private String Nombre;
	private int Ubicacion;
	private Date fechaMarcha;
	private Date fechaCierre;
	private String[] Fuerzas;
	
	public String getNombre() {
		return Nombre;
	}
	public void setNombre(String nombre) {
		Nombre = nombre;
	}
	public int getUbicacion() {
		return Ubicacion;
	}
	public void setUbicacion(int ubicacion) {
		Ubicacion = ubicacion;
	}
	public Date getFechaMarcha() {
		return fechaMarcha;
	}
	public void setFechaMarcha(Date fechaMarcha) {
		this.fechaMarcha = fechaMarcha;
	}
	public Date getFechaCierre() {
		return fechaCierre;
	}
	public void setFechaCierre(Date fechaCierre) {
		this.fechaCierre = fechaCierre;
	}
	public int getIDCCDTyE() {
		return IDCCDTyE;
	}
	public void setIDCCDTyE(int iDCCDTyE) {
		IDCCDTyE = iDCCDTyE;
	}
	public String[] getFuerzas() {
		return Fuerzas;
	}
	public void setFuerzas(String[] fuerzas) {
		Fuerzas = fuerzas;
	}
	

}
