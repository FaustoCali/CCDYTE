package estructuraTP.modelo;

public class Identificado extends Detenido {
	private String Biografia;
	private int ContAV;
	public String getBiografia() {
		return Biografia;
	}
	public void setBiografia(String biografia) {
		Biografia = biografia;
	}
	public int getContAV() {
		return ContAV;
	}
	public void setContAV(int contAV) {
		ContAV = contAV;
	}

}
