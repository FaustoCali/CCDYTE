package estructuraTP.modelo;

public class NoIdentificado  extends Detenido{
	private String Apodo;
	private String Descripcion;
	public String getApodo() {
		return Apodo;
	}
	public void setApodo(String apodo) {
		Apodo = apodo;
	}
	public String getDescripcion() {
		return Descripcion;
	}
	public void setDescripcion(String descripcion) {
		Descripcion = descripcion;
	}

}
