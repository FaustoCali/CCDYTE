package estructuraTP.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import estructuraTP.modelo.CCDTyE;

public class CCDTyEDao {
	Connection conn = null;
	public void guardar(CCDTyE Centro) {
		String url = "jdbc:mysql://localhost:3306/esotilin";
		String usuario = "root";
		String contrasenia = "admin";		
		
		try {
			conn = DriverManager.getConnection(url, usuario, contrasenia);
			PreparedStatement prepareStatement = conn.prepareStatement("INSERT INTO `CCDTyE` (`IDCCDTyE`, `NombreCCDTyE`,`Ubicacion`.`fechaMarcha`,`fechaCierre`) VALUES (?, ?)");
			prepareStatement.setInt(1,Centro.getIDCCDTyE() );
			prepareStatement.setString(2,Centro.getNombre());
			prepareStatement.setInt(3, Centro.getUbicacion());
			prepareStatement.setDate(4, Centro.getFechaMarcha());
			prepareStatement.setDate(5, Centro.getFechaCierre());
			
			int i = prepareStatement.executeUpdate();
			System.out.println(i);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("No pude");
			e.printStackTrace();
		}finally {
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	public void MostrarTodos() {
		Statement statement = null;
		 
		String query = "select IDCCDTyE, NombreCCDTyE, Ubicacion, fechaMarcha, fechaCierre from CCDTyE";
 
		try{			
			//get connection
 
			//create statement
			statement = conn.createStatement();
 
			//execute query
			ResultSet rs = statement.executeQuery(query);
			while (rs.next()) {				 
			  // String empId = rs.getString("idtilines");
			   //String empName = rs.getString("NombreTilin");
 
			  // System.out.println("idtilines : " + empId);
			  // System.out.println("Nombretilines : " + empName); 
			}
 
			//close connection
			statement.close();
		}catch(Exception e){ 
			e.printStackTrace();
		}finally {
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
