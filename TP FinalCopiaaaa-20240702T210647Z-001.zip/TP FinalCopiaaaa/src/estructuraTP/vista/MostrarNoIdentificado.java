package estructuraTP.vista;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

import estructuraTP.dao.CCDTyEDao;
import estructuraTP.dao.FuerzaDao;
import estructuraTP.dao.IdentificadoDao;
import estructuraTP.dao.NoIdentificadoDao;
import estructuraTP.modelo.CCDTyE;
import estructuraTP.modelo.Identificado;
import estructuraTP.modelo.NoIdentificado;

public class MostrarNoIdentificado extends JPanel {
	private JTable table;
	private ArrayList<NoIdentificado> todosLosDetenidos;
	public MostrarNoIdentificado() {
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(22, 11, 321, 222);
		add(scrollPane);

		
		table = new JTable();
		//add(table);
		scrollPane.setViewportView(table);
		
		DefaultTableModel modelo = new DefaultTableModel();
		modelo.addColumn("DNI");
		modelo.addColumn("Apodo");
		modelo.addColumn("Descripcion");
		table.setModel(modelo);

		NoIdentificadoDao Centro = new NoIdentificadoDao();
		
		
		
		todosLosDetenidos = Centro.MostrarTodos();
		
		
		for (NoIdentificado Ide : todosLosDetenidos) {
			modelo.addRow(new Object[] {Ide.getDNIDetenido(),Ide.getNombreDetenido(),Ide.getDescripcion()});
		}
		
		//JButton altasButton = new JButton("Altas");
		//altasButton.addActionListener(new ActionListener() {
			//public void actionPerformed(ActionEvent e) {
				//JFrame marco = (JFrame) SwingUtilities.getWindowAncestor((Component) e.getSource());
				//marco.setContentPane(new Alta());
				//marco.validate();
			//}
		//});
		//add(altasButton);
 
		JButton bajasButton = new JButton("Bajas");
		bajasButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame marco = (JFrame) SwingUtilities.getWindowAncestor((Component) e.getSource());
				marco.setContentPane(new BajaNoIdentificado());
				marco.validate();
			}
		});
		add(bajasButton);

		JButton modificacionesButton = new JButton("Modificaciones");
		modificacionesButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int filaElegida = table.getSelectedRow();
				NoIdentificado DetenidoElegido = null;
				if(filaElegida >= 0) {
					DetenidoElegido = todosLosDetenidos.get(filaElegida);
				}
				JFrame marco = (JFrame) SwingUtilities.getWindowAncestor((Component) e.getSource());
				marco.setContentPane(new ModificacionNoIdentificados(DetenidoElegido));
				marco.validate();
			}
		});
		add(modificacionesButton);

	}

}
