package estructuraTP.vista;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import estructuraTP.dao.CCDTyEDao;
import estructuraTP.dao.FuerzaDao;
import estructuraTP.modelo.CCDTyE;

public class ModificacionFuerzas extends JPanel {

	private JTextField txtNombre;
	private JTextField txtNombre2;
	private CCDTyE centroElegido;

	public ModificacionFuerzas() {

		JLabel lblNombre = new JLabel("Nombre");
		lblNombre.setBounds(25, 25, 46, 14);
		add(lblNombre);

		txtNombre = new JTextField();
		txtNombre.setBounds(81, 22, 86, 20);
		add(txtNombre);
		txtNombre.setColumns(50);
		
		JLabel lblNombre2 = new JLabel("IDCCDTyE");
		lblNombre2.setBounds(25, 25, 46, 14);
		add(lblNombre);

		txtNombre2 = new JTextField();
		txtNombre2.setBounds(81, 22, 86, 20);
		add(txtNombre2);
		txtNombre2.setColumns(50);

		
		

		JButton btnGuardar = new JButton("Modifica la ubicacion que pongas");

		btnGuardar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				String nombre = txtNombre.getText();
				int putamadreabuela =  Integer.parseInt(txtNombre2.getText());


				FuerzaDao Fdao = new FuerzaDao();
				String mensaje = "";
				if(centroElegido == null) {
				  
				}else {
					
				}

			}
		});
		btnGuardar.setBounds(78, 295, 89, 23);
		add(btnGuardar);

		JButton btnNewButton = new JButton("Volver");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame marco = (JFrame) SwingUtilities.getWindowAncestor((Component) e.getSource());
				marco.setContentPane(new MostrarCCDTyE());
				marco.validate();

			}
		});
		btnNewButton.setBounds(351, 266, 89, 23);
		add(btnNewButton);

	}

	public ModificacionFuerzas(CCDTyE centroElegido) {
		this();
		this.centroElegido = centroElegido;
		if(centroElegido == null) {
			
			txtNombre.setText("");
			
		}else {
			txtNombre.setText(centroElegido.getNombre());
		}
		
	}

}
