package estructuraTP.vista;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import estructuraTP.dao.CCDTyEDao;
import estructuraTP.dao.CCDTyE_IdentificadoDao;
import estructuraTP.dao.IdentificadoDao;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

public class BajaIdentificado extends JPanel {
	private JTextField textField;
	public BajaIdentificado() {
		
		JLabel lblNewLabel = new JLabel("Introduce La id A ELIMINAR");
		add(lblNewLabel);
		
		textField = new JTextField();
		add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("Elimina la ubicacion eliegida ");
		add(btnNewButton);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				IdentificadoDao test = new IdentificadoDao();
				CCDTyE_IdentificadoDao test2 = new CCDTyE_IdentificadoDao();
				int mecagoentodo = Integer.valueOf(textField.getText());
				test.EliminarPorID(mecagoentodo);
				test2.eliminarCCDTYE_DDNI(mecagoentodo);
				
			}
		
	


	});
		JButton btnCboton = new JButton("Volver");
		btnCboton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame marco = (JFrame) SwingUtilities.getWindowAncestor((Component) e.getSource());
				marco.setContentPane(new MostrarCCDTyE());
				marco.validate();

			}
		});
		btnCboton.setBounds(351, 266, 89, 23);
		add(btnCboton);

	}
}

