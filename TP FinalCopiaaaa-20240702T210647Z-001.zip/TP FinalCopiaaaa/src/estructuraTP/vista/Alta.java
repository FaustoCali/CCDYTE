package estructuraTP.vista;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import estructuraTP.dao.CCDTyEDao;
import estructuraTP.modelo.CCDTyE;

import javax.swing.JButton;
import javax.swing.JFrame;

import java.awt.event.ActionListener;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.awt.Component;
import java.awt.Window;
import java.awt.event.ActionEvent;


public class Alta extends JPanel {
	protected static final String[] FuerzaID = null;
	private JTextField txtNombre;
	private JTextField txtLegajo;
	private JTextField txtFecha;
	private JTextField txtFecha2;
	private JTextField txtFuerzaID;
	
	public Alta() {
	
		
		JLabel lblNombre = new JLabel("Nombre");
		lblNombre.setBounds(25, 25, 46, 14);
		add(lblNombre);
		
		txtNombre = new JTextField();
		txtNombre.setBounds(81, 22, 86, 20);
		add(txtNombre);
		txtNombre.setColumns(50);
		
		JLabel lblLegajo = new JLabel("Ubicacion");
		lblLegajo.setBounds(25, 75, 46, 14);
		add(lblLegajo);
		
		txtLegajo = new JTextField();
		txtLegajo.setBounds(81, 72, 86, 20);
		add(txtLegajo);
		txtLegajo.setColumns(50);
		
		JLabel lblFecha1 = new JLabel("FechaApertura");
		lblFecha1.setBounds(25, 125, 46, 14);
		add(lblFecha1);
		
		txtFecha = new JTextField();
		txtFecha.setBounds(81, 122, 86, 20);
		add(txtFecha);
		txtFecha.setColumns(50);
		
		JLabel lblFecha2 = new JLabel("FechaCierre");
		lblFecha2.setBounds(25, 175, 46, 14);
		add(lblFecha2);
		
		txtFecha2 = new JTextField();
		txtFecha2.setBounds(81, 172, 86, 20);
		add(txtFecha2);
		txtFecha2.setColumns(50);
		
		
		JButton btnGuardar = new JButton("Guardar");
		
		btnGuardar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
				    String nombre = txtNombre.getText();
				    int Ubicacion = Integer.valueOf(txtLegajo.getText());
				    LocalDate fecha = LocalDate.parse(txtFecha.getText(), DateTimeFormatter.ofPattern("yyyy-MM-dd"));
				    LocalDate fecha2 = LocalDate.parse(txtFecha2.getText(), DateTimeFormatter.ofPattern("yyyy-MM-dd"));

				    CCDTyE centro = new CCDTyE(nombre, Ubicacion, fecha, fecha2,FuerzaID);

				    CCDTyEDao test = new CCDTyEDao();
				    String mensaje = "";
				    test.guardar(centro);
				} catch (DateTimeParseException e1) {
				    System.out.println("Error: " + e1.getMessage());
				    // Handle the parsing error here
				}
				}

		});
		btnGuardar.setBounds(78, 295, 89, 23);
		add(btnGuardar);
		JButton btnNewButton = new JButton("Volver");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame marco = (JFrame) SwingUtilities.getWindowAncestor((Component) e.getSource());
				marco.setContentPane(new MostrarCCDTyE());
				marco.validate();

			}
		});
		btnNewButton.setBounds(351, 266, 89, 23);
		add(btnNewButton);

	}


	

}
