package estructuraTP.modelo;

import java.sql.Date;
import java.time.LocalDate;

public class Identificado extends Detenido {
	private String Biografia;
	private String ContAV;
	
	public Identificado(int dNIDetenido, String nombreDetenido, int lugarSecuestro,
			LocalDate ulVisto, String biografia, String contAV) {
		super(dNIDetenido, nombreDetenido, lugarSecuestro, ulVisto);
		Biografia = biografia;
		ContAV = contAV;
	}


	public String getBiografia() {
		return Biografia;
	}
	public void setBiografia(String biografia) {
		Biografia = biografia;
	}
	public String getContAV() {
		return ContAV;
	}
	public void setContAV(String contAV) {
		ContAV = contAV;
	}

}
