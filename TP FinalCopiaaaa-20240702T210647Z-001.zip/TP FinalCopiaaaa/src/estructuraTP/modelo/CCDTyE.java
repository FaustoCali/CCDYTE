package estructuraTP.modelo;

import java.sql.Date;
import java.time.LocalDate;

public class CCDTyE {
	private String Nombre;
	private int Ubicacion;
	private LocalDate fechaMarcha;
	private LocalDate fechaCierre;
	private String Fuerzas[];

	
	
	
	public CCDTyE(String nombre, int ubicacion, LocalDate fechaMarcha, LocalDate fechaCierre, String[] Fue) {
		super();
		Nombre = nombre;
		Ubicacion = ubicacion;
		this.fechaMarcha = fechaMarcha;
		this.fechaCierre = fechaCierre;
		this.setFuerzas(Fue);

	}
	public String getNombre() {
		return Nombre;
	}
	public void setNombre(String nombre) {
		Nombre = nombre;
	}
	public int getUbicacion() {
		return Ubicacion;
	}
	public void setUbicacion(int ubicacion) {
		Ubicacion = ubicacion;
	}
	public LocalDate getFechaMarcha() {
		return fechaMarcha;
	}
	public void setFechaMarcha(LocalDate fechaMarcha) {
		this.fechaMarcha = fechaMarcha;
	}
	public LocalDate getFechaCierre() {
		return fechaCierre;
	}
	public void setFechaCierre(LocalDate fechaCierre) {
		this.fechaCierre = fechaCierre;
	}
	public String[] getFuerzas() {
		return Fuerzas;
	}
	public void setFuerzas(String fuerzas[]) {
		Fuerzas = fuerzas;
	}
	
	

}
