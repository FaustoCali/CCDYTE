package estructuraTP.modelo;

import java.sql.Date;
import java.time.LocalDate;

public class NoIdentificado  extends Detenido{
	private String Apodo;
	private String Descripcion;
	
	public NoIdentificado(int dNIDetenido2, String nombreDetenido2, int lugarSecuestro2,
			LocalDate ulVisto2, String apodo, String descripcion) {
		super(dNIDetenido2, nombreDetenido2, lugarSecuestro2, ulVisto2);
		Apodo = apodo;
		Descripcion = descripcion;
	}
	public String getApodo() {
		return Apodo;
	}
	public void setApodo(String apodo) {
		Apodo = apodo;
	}
	public String getDescripcion() {
		return Descripcion;
	}
	public void setDescripcion(String descripcion) {
		Descripcion = descripcion;
	}

}
