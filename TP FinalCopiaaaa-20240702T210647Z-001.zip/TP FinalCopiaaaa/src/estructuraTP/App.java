package estructuraTP;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.JFrame;

import estructuraTP.dao.CCDTyEDao;
import estructuraTP.modelo.CCDTyE;
import estructuraTP.vista.Alta;
import estructuraTP.vista.BajaCCDTyE;
import estructuraTP.vista.ModificacionCCDTyE;
import estructuraTP.vista.MostrarCCDTyE;

public class App {

	public static void main(String args[]) {
	
	
	 
			JFrame marco = new JFrame();
			marco.setVisible(true);
			marco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			marco.setBounds(10, 10, 1280, 720);
			marco.setContentPane(new MostrarCCDTyE());
			marco.validate();

		
	
	

}
}
