package estructuraTP.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class FuerzaDao {
	Conexion c = new Conexion();
	public void relacionarFuerzas(String[] fuerza, int idCCDTyE) {
		try {
			c.ConexionBD();
			
			for(int i = 0 ;i < fuerza.length;i++) {
				PreparedStatement prepareStatement = c.getConn().prepareStatement(
						"Insert into tp_final.ccdtye_fuerza(IDccdtye,IDFuerza) values ((select IDccdtye from ccdtye where Ubicacion = ? ),(select IDFuerza from fuerza where Nombre_Fuerza = ?))");
				
				prepareStatement.setInt(1, idCCDTyE);
				prepareStatement.setString(2, fuerza[i] );
				int i1 = prepareStatement.executeUpdate();
				System.out.println(i1);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("No se ha insertado el registro");
			
		} finally {
			c.CierreConexionBD();

		}
	}
	public void eliminarFuerzas(int idCCDTyE) {
		try {
			c.ConexionBD();
			PreparedStatement prepareStatement = c.getConn().prepareStatement(
				"DELETE FROM ccdtye_fuerza WHERE IDCCDTyE = ?");
			prepareStatement.setInt(1, idCCDTyE);
			int i1 = prepareStatement.executeUpdate();
			System.out.println(i1);
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("No se ha insertado el registro");
			
		} finally {
			c.CierreConexionBD();

		}
	}
	public String[] encontrarFuerzasPorCentro(int idCentro) {
	    try {
	        c.ConexionBD();

	        ArrayList<String> fuerzaList = new ArrayList<>();

	        PreparedStatement preparedStatement = c.getConn().prepareStatement(
	                "select f.Nombre_Fuerza from fuerza f inner join ccdtye_fuerza cf on f.IDFuerza = cf.IDFuerza where cf.IDCCDTyE = ?");
	        preparedStatement.setInt(1, idCentro);
	        ResultSet rs = preparedStatement.executeQuery();

	        while (rs.next()) {
	            fuerzaList.add(rs.getString("Nombre_Fuerza"));
	        }

	        String[] fuerza = new String[fuerzaList.size()];
	        fuerza = fuerzaList.toArray(fuerza);

	        
	        if (fuerza != null) {
	            for (String nombreFuerza : fuerza) {
	                System.out.println(nombreFuerza);
	            }
	        } else {
	            System.out.println("El array de fuerzas es nulo.");
	        }

	        return fuerza;
	    } catch (SQLException e) {
	        e.printStackTrace();
	        System.out.println("No se ha insertado el registro");
	        return null;
	    } finally {
	        c.CierreConexionBD();
	    }
	}

}
