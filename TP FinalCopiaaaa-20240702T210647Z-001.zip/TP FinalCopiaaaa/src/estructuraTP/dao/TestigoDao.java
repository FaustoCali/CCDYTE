package estructuraTP.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import estructuraTP.modelo.CCDTyE;
import estructuraTP.modelo.Testigo;

public class TestigoDao {
	
	public Connection conexion () {
		Connection conn = null;
		String url = "jdbc:mysql://localhost:3306/tp_final";
		String usuario = "root";
		String contrasenia = "admin";	
		try {
			conn = DriverManager.getConnection(url, usuario, contrasenia);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
		
	}
	public void guardar(Testigo Testi) {
		String url = "jdbc:mysql://localhost:3306/tp_final";
		String usuario = "root";
		String contrasenia = "admin";	
		Connection conn = conexion();
		
		try {
			conn = DriverManager.getConnection(url, usuario, contrasenia);
			PreparedStatement prepareStatement = conn.prepareStatement("INSERT INTO `ccdtye` (`DNI_Testigo`, `Nombre_Completo_Testigo`,`Testimonio`) VALUES (?, ?,?)");
			prepareStatement.setInt(1,Testi.getDNI_Testigo());
			prepareStatement.setString(2, Testi.getNombre_Completo_Testigo());
			prepareStatement.setString(2, Testi.getTestimonio());
			
			int i = prepareStatement.executeUpdate();
			System.out.println(i);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("No pude");
			e.printStackTrace();
		}
			
	}
	public ArrayList<Object[]> MostrarTodos() {
		Connection conn = conexion();
		Statement statement = null;
		  ArrayList<Object[]> Test = new ArrayList<Object[]>();
		String query = "select DNI_Testigo, Nombre_Completo_Testigo,Testimonio from ccdtye";
 
		try{			
			//get connection
 
			//create statement
			statement = conn.createStatement();
			 
			//execute query
			ResultSet rs = statement.executeQuery(query);
			while (rs.next()) {				 
			  int empId = rs.getInt("DNI_Testigo");
			   String empName = rs.getString("Nombre_Completo_Testigo");
			   String empTest = rs.getString("Testimonio");
			  
			   
			   Object[] fila = new Object[] {empName,empId,empTest };
			   Test.add(fila);
			
			   
			   

			}
 
			//close connection
			statement.close();
		}catch(Exception e){ 
			e.printStackTrace();
		}
		return Test;
	}
	public void EliminarPorID(int test) {
		Connection conn = conexion();
		String url = "jdbc:mysql://localhost:3306/tp_final";
		String usuario = "root";
		String contrasenia = "admin";	

		

		try{
			conn = DriverManager.getConnection(url, usuario, contrasenia);
			
			PreparedStatement prepareStatement = conn.prepareStatement("DELETE from Testigo Where DNI_Testigo =  "+test);
			//get connection

			//create statement
			int i = prepareStatement.executeUpdate();
			System.out.println(i);
			
			


			//close connection
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public void modificar(Testigo Testi, String nombre) {
		Connection conn = conexion();
	    String url = "jdbc:mysql://localhost:3306/tpfinal";
	    String usuario = "root";
	    String contrasenia = "admin";

	    try {
	        conn = DriverManager.getConnection(url, usuario, contrasenia);
	        PreparedStatement prepareStatement = conn.prepareStatement("UPDATE `tp_final`.`testigo SET `DNI_Testigo`= ?, `Nombre_Completo_Testigo`= ?,`Testimonio` = ? WHERE DNI_Testigo ="+ nombre);
	        prepareStatement.setInt(1,Testi.getDNI_Testigo());
			prepareStatement.setString(2, Testi.getNombre_Completo_Testigo());
			prepareStatement.setString(2, Testi.getTestimonio());

	        int i = prepareStatement.executeUpdate();
	        System.out.println(i);

	    } catch (SQLException e) {
	        System.out.println("No pude");
	        e.printStackTrace();
	    }
	}
	  public int obtenerProximoId() {
	        Connection conn = conexion();
	        Statement statement = null;
	        ResultSet resultSet = null;

	        try {

	            // Consulta para obtener el próximo ID autoincremental
	            String query = "SELECT AUTO_INCREMENT FROM information_schema.TABLES WHERE TABLE_SCHEMA = 'tu_base_de_datos' AND TABLE_NAME = 'tu_tabla'";
	            
	            statement = conn.createStatement();
	            resultSet = statement.executeQuery(query);

	            if (resultSet.next()) {
	                return resultSet.getInt("AUTO_INCREMENT");
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        } finally {
	            // Cerrar recursos (resultSet, statement, connection) en el bloque finally
	        }

	        // Manejo de errores o valor por defecto si algo sale mal
	        return -1;
	    }

}
