package estructuraTP.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;



public class CCDTyE_NoIdentificadoDao {
	private Conexion c = new Conexion();
	public void realcionarCCDTyE_DDNI(int iddn, int idcc) {
		try {
			c.ConexionBD();
			PreparedStatement prepareStatement = c.getConn().prepareStatement(
					"INSERT INTO `ccdtye_no_identificado`(`IDccdtyeFKI`,`IDno_identificadoFKI`)VALUES(?,?);");
			prepareStatement.setInt(3, iddn);
			prepareStatement.setInt(3, idcc);
            int i = prepareStatement.executeUpdate();
			System.out.println(i);
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("No se ha inseratado el registro");
		} finally {
			c.CierreConexionBD();

		}
	}
	
	public void eliminarCCDTYE_DDNI(int idCCDTyE) {
		try {
			c.ConexionBD();
			PreparedStatement prepareStatement = c.getConn().prepareStatement(
				"DELETE FROM ccdtye_no_identificado WHERE IDno_identificadoFKI = ?");
			prepareStatement.setInt(1, idCCDTyE);
			int i1 = prepareStatement.executeUpdate();
			System.out.println(i1);
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("No se ha insertado el registro");
			
		} finally {
			c.CierreConexionBD();

		}
	}
	public String encontrarCCDTYE(int idCentro) {
		String test8 = "";
	    try {
	        c.ConexionBD();
	        

	        

	        PreparedStatement preparedStatement = c.getConn().prepareStatement(
	                "SELECT Nombre_ccdtye from ccdtye WHERE IDccdtye = (Select IDccdtyeFKI from ccdtye_no_identificado Where IDno_identificadoFKI = ?))");
	        preparedStatement.setInt(1, idCentro);
	        ResultSet rs = preparedStatement.executeQuery();

	        while (rs.next()) {
	        	test8 = rs.getString("Nombre_ccdtye");
	        	
	        }
	        
	        return test8;


	        
	      
	    } catch (SQLException e) {
	        e.printStackTrace();
	        System.out.println("No se ha insertado el registro");
	        return test8;
	    } finally {
	        c.CierreConexionBD();
	    }
	}

}
