package estructuraTP.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import estructuraTP.modelo.CCDTyE;
import estructuraTP.modelo.Identificado;
import estructuraTP.modelo.NoIdentificado;

public class NoIdentificadoDao {
	Conexion c = new Conexion();
	Connection conn = c.getConn();
	
	public void guardar(Identificado Id) {
		
		
		try {
			c.ConexionBD();
			PreparedStatement prepareStatement = c.getConn().prepareStatement("INSERT INTO `no_identificado` (`DNI_identificado`, `Apodo`,`Descripcion`,`Fecha_Ultimo_Avistamiento`,`Biografia_Personal`,`MaterialAV`,`DNI_TestigoFK`) VALUES (?, ?,?,?,?,?,?)");
	        prepareStatement.setInt(1,Id.getDNIDetenido());
	        prepareStatement.setString(2,Id.getNombreDetenido());
	        Date test2 = Date.valueOf(Id.getUlVisto());
	        prepareStatement.setInt(3,Id.getLugarSecuestro());
	        prepareStatement.setDate(4, test2);
	        prepareStatement.setString(5,Id.getBiografia());
	        prepareStatement.setString(6,Id.getContAV());
			
			int i = prepareStatement.executeUpdate();
			System.out.println(i);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("No pude");
			e.printStackTrace();
		}
			
	}
	public ArrayList<NoIdentificado> MostrarTodos() {
		c.ConexionBD();
		Statement statement = null;
		  ArrayList<NoIdentificado> Test = new ArrayList<NoIdentificado>();
		String query = "select `DNI_identificado`, `Nombre_Completo_Identificado`,`Lugar_Secuestro`,`Fecha_Ultimo_Avistamiento`,`Biografia_Personal`,`MaterialAV`,`DNI_TestigoFK` from identificado";

 
		try{			
			//get connection
			FuerzaDao Fdao = new FuerzaDao();
 
			//create statement
			statement = c.getConn().createStatement();
			 
			//execute query
			ResultSet rs = statement.executeQuery(query);
			while (rs.next()) {			 
			  int empId = rs.getInt("DNI_identificado");
			   String empName = rs.getString("Nombre_Completo_Identificado");
			  int FechaOp = rs.getInt("Lugar_Secuestro");
			   Date FechaCi = rs.getDate("Fecha_Ultimo_Avistamiento");
			   String Bio = rs.getString("Biografia_Personal");
			   String Material = rs.getString("MaterialAV");
			   NoIdentificado c = new NoIdentificado( empId, empName, FechaOp, FechaCi.toLocalDate(),Bio,Material);
			   
			   
			   Test.add(c);
			
			   
			   

			}
 
			//close connection
			statement.close();
		}catch(Exception e){ 
			e.printStackTrace();
		}
		return Test;
	}
	public void EliminarPorID(int test) {
		
		c.ConexionBD();
		

		try{
			
			
			PreparedStatement prepareStatement = conn.prepareStatement("DELETE from identificado Where DNI_identificado =  "+test);
			//get connection

			//create statement
			int i = prepareStatement.executeUpdate();
			System.out.println(i);
	
			


			//close connection
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public void modificar(Identificado Id, String nombre) {
		c.ConexionBD();

	    try {
	        PreparedStatement prepareStatement = conn.prepareStatement("UPDATE `tp_final`.`identificado` SET `DNI_identificado`= ?, `Nombre_Completo_Identificado`= ?,`Lugar_Secuestro` = ?, `Fecha_Ultimo_Avistamiento` = ?, `Biografia_Personal` = ?, `MaterialAV` = ?,   WHERE Nombre_Completo_Identificado ="+ nombre);
	        prepareStatement.setInt(1,Id.getDNIDetenido());
	        prepareStatement.setString(2,Id.getNombreDetenido());
	        Date test2 = Date.valueOf(Id.getUlVisto());
	        prepareStatement.setInt(3,Id.getLugarSecuestro());
	        prepareStatement.setDate(4, test2);
	        prepareStatement.setString(5,Id.getBiografia());
	        prepareStatement.setString(6,Id.getContAV());

	        int i = prepareStatement.executeUpdate();
	        System.out.println(i);

	    } catch (SQLException e) {
	        System.out.println("No pude");
	        e.printStackTrace();
	    }
	}
	public int obtenerProximoId() {
		c.ConexionBD();
        Statement statement = null;
        ResultSet resultSet = null;

        try {

            // Consulta para obtener el próximo ID autoincremental
            String query = "SELECT AUTO_INCREMENT FROM information_schema.TABLES WHERE TABLE_SCHEMA = 'tp_final' AND TABLE_NAME = 'no_identificado'";
            
            statement = conn.createStatement();
            resultSet = statement.executeQuery(query);

            if (resultSet.next()) {
                return resultSet.getInt("AUTO_INCREMENT");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Cerrar recursos (resultSet, statement, connection) en el bloque finally
        }

        // Manejo de errores o valor por defecto si algo sale mal
        return -1;
    }


}
