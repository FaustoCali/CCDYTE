package estructuraTP.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
	private String url = "jdbc:mysql://localhost:3306/tp_final";
	private String usuario = "root";
	private String contrasenia = "admin";
 
	private Connection conn;
   public Connection getConn() {
		return conn;
	}
	public void setConn(Connection conn) {
		this.conn = conn;
	}

	public  void ConexionBD() {
		
		try {
			conn = DriverManager.getConnection(url,usuario,contrasenia);
			
			if(conn != null) {
				System.out.println("Establecio la contexion  ");
			}
		}
		catch(SQLException e){
			System.out.println("Falla de contexion");
			
			e.printStackTrace();
			
		}
		
	}
	public  void CierreConexionBD() {
		
		try {
			conn.close();
			
			if(conn == null) {
				System.out.println("Se cerro la conexion");
			}
		}
		catch(SQLException e){
			System.out.println("Falla de cierre contexion");
			
			e.printStackTrace();
			
		}
		
	}

}

