package estructuraTP.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import estructuraTP.modelo.CCDTyE;
import estructuraTP.modelo.Testigo;

public class TestDao {
	Conexion c = new Conexion();
	Connection conn = c.getConn();
	
	public void guardar(Testigo Testi) {
		
		
		try {
			c.ConexionBD();
			PreparedStatement prepareStatement = conn.prepareStatement("INSERT INTO `ccdtye` (`DNI_Testigo`, `Nombre_Completo_Testigo`,`Testimonio`) VALUES (?, ?,?)");
			prepareStatement.setInt(1,Testi.getDNI_Testigo());
			prepareStatement.setString(2, Testi.getNombre_Completo_Testigo());
			prepareStatement.setString(2, Testi.getTestimonio());
			
			int i = prepareStatement.executeUpdate();
			System.out.println(i);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("No pude");
			e.printStackTrace();
		}
			
	}
	public ArrayList<Testigo> MostrarTodos() {
		c.ConexionBD();
		  ArrayList<Testigo> Test = new ArrayList<Testigo>();
		String query = "select DNI_Testigo, Nombre_Completo_Testigo,Testimonio from ccdtye";
 
		try{			
			//get connection
 
			//create statement
			Statement statement = conn.createStatement();
			 
			//execute query
			ResultSet rs = statement.executeQuery(query);
			while (rs.next()) {				 
			  int empId = rs.getInt("DNI_Testigo");
			   String empName = rs.getString("Nombre_Completo_Testigo");
			   String empTest = rs.getString("Testimonio");
			  
			   
			   Testigo fila = new Testigo(empId,empName,empTest);
			   Test.add(fila);
			
			   
			   

			}
 
			//close connection
			statement.close();
		}catch(Exception e){ 
			e.printStackTrace();
		}
		return Test;
	}
	public void EliminarPorID(int test) {
		
		c.ConexionBD();
		

		try{
			//conn = DriverManager.getConnection(url, usuario, contrasenia);
			
			PreparedStatement prepareStatement = conn.prepareStatement("DELETE from Testigo Where DNI_Testigo =  "+test);
			//get connection

			//create statement
			int i = prepareStatement.executeUpdate();
			System.out.println(i);
			
			


			//close connection
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public void modificar(Testigo Testi, int test) {
		c.ConexionBD();

	    try {
	    	 PreparedStatement prepareStatement = conn.prepareStatement("UPDATE `tp_final`.`testigo SET `DNI_Testigo`= ?, `Nombre_Completo_Testigo`= ?,`Testimonio` = ? WHERE DNI_Testigo ="+ test);
		        prepareStatement.setInt(1,Testi.getDNI_Testigo());
				prepareStatement.setString(2, Testi.getNombre_Completo_Testigo());
				prepareStatement.setString(2, Testi.getTestimonio());

		        int i = prepareStatement.executeUpdate();
		        System.out.println(i);

	    } catch (SQLException e) {
	        System.out.println("No pude");
	        e.printStackTrace();
	    }
	}
	public int obtenerProximoId() {
		c.ConexionBD();
        Statement statement = null;
        ResultSet resultSet = null;

        try {

            // Consulta para obtener el próximo ID autoincremental
            String query = "SELECT AUTO_INCREMENT FROM information_schema.TABLES WHERE TABLE_SCHEMA = 'tp_final' AND TABLE_NAME = 'testigo'";
            
            statement = conn.createStatement();
            resultSet = statement.executeQuery(query);

            if (resultSet.next()) {
                return resultSet.getInt("AUTO_INCREMENT");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Cerrar recursos (resultSet, statement, connection) en el bloque finally
        }

        // Manejo de errores o valor por defecto si algo sale mal
        return -1;
    }


}
