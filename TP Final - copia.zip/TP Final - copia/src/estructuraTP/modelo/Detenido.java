package estructuraTP.modelo;

import java.sql.Date;

public abstract class Detenido {
	private int DNIDetenido;
	private String NombreDetenido;
	private String ApellidoDetenido;
	private int LugarSecuestro;
	private Date UlVisto;
	public int getDNIDetenido() {
		return DNIDetenido;
	}
	public void setDNIDetenido(int dNIDetenido) {
		DNIDetenido = dNIDetenido;
	}
	public String getNombreDetenido() {
		return NombreDetenido;
	}
	public void setNombreDetenido(String nombreDetenido) {
		NombreDetenido = nombreDetenido;
	}
	public String getApellidoDetenido() {
		return ApellidoDetenido;
	}
	public void setApellidoDetenido(String apellidoDetenido) {
		ApellidoDetenido = apellidoDetenido;
	}
	public int getLugarSecuestro() {
		return LugarSecuestro;
	}
	public void setLugarSecuestro(int lugarSecuestro) {
		LugarSecuestro = lugarSecuestro;
	}
	public Date getUlVisto() {
		return UlVisto;
	}
	public void setUlVisto(Date ulVisto) {
		UlVisto = ulVisto;
	}

}
