package estructuraTP.modelo;

public class Testigo {
	private int DNI_Testigo;
	private String Nombre_Completo_Testigo;
	private String Testimonio;
	public String getNombre_Completo_Testigo() {
		return Nombre_Completo_Testigo;
	}
	public void setNombre_Completo_Testigo(String nombre_Completo_Testigo) {
		Nombre_Completo_Testigo = nombre_Completo_Testigo;
	}
	public String getTestimonio() {
		return Testimonio;
	}
	public void setTestimonio(String testimonio) {
		Testimonio = testimonio;
	}
	public int getDNI_Testigo() {
		return DNI_Testigo;
	}
	public void setDNI_Testigo(int dNI_Testigo) {
		DNI_Testigo = dNI_Testigo;
	}

}
