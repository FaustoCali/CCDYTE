package estructuraTP;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.SQLException;

import estructuraTP.dao.CCDTyEDao;
import estructuraTP.modelo.CCDTyE;

public class App {
	public static Connection conn = null; 
	public static void Conectar() {
		String url = "jdbc:mysql://localhost:3306/esotilin";
		String usuario = "root";
		String contrasenia = "admin";
		
		try {
			// 1.
			conn = DriverManager.getConnection(url, usuario, contrasenia);
			// 2.

			if (conn != null) {
				System.out.println("Conexi�n exitosa.");
			}
			
		} catch (SQLException e) {
			System.out.println("No pudo establecerse la conexi�n.");
			e.printStackTrace();
		}
	}
	public static void main(String args[]) {
	
		
		Date test777 = new Date(80999);
		Date test888 = new Date(90999);
		String[] test999 = {"1","2"};
		
		CCDTyE test = new CCDTyE(1,"test",10,test777,test888,test999);
		CCDTyEDao test1000 = new CCDTyEDao();
		test1000.guardar(test);
		test1000.MostrarTodos();
		test1000.EliminarPorID(7);
		test1000.MostrarTodos();
		
	}
	

}
