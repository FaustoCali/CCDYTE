package estructuraTP.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import estructuraTP.modelo.CCDTyE;

public class CCDTyEDao {
	Connection conn = null;
	public void guardar(CCDTyE Centro) {
		String url = "jdbc:mysql://localhost:3306/tpfinal";
		String usuario = "root";
		String contrasenia = "admin";		
		
		try {
			conn = DriverManager.getConnection(url, usuario, contrasenia);
			PreparedStatement prepareStatement = conn.prepareStatement("INSERT INTO `ccdtye` (`Ubicacion`, `Nombre_ccdtye`,`Fecha_Apertura`,`Fecha_Cierre`) VALUES (?, ?,?,?)");
			prepareStatement.setInt(1,Centro.getUbicacion() );
			prepareStatement.setString(2,Centro.getNombre());
			prepareStatement.setDate(3, Centro.getFechaMarcha());
			prepareStatement.setDate(4, Centro.getFechaCierre());
			
			int i = prepareStatement.executeUpdate();
			System.out.println(i);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("No pude");
			e.printStackTrace();
		}
			
	}
	public void MostrarTodos() {
		Statement statement = null;
		 
		String query = "select Ubicacion, Nombre_ccdtye,Fecha_Apertura,Fecha_Cierre from ccdtye";
 
		try{			
			//get connection
 
			//create statement
			statement = conn.createStatement();
 
			//execute query
			ResultSet rs = statement.executeQuery(query);
			while (rs.next()) {				 
			  int empId = rs.getInt("Ubicacion");
			   String empName = rs.getString("Nombre_ccdtye");
 
			   System.out.println("idtilines : " + empId);
			  System.out.println("Nombretilines : " + empName); 
			}
 
			//close connection
			statement.close();
		}catch(Exception e){ 
			e.printStackTrace();
		}
	}
	public void EliminarPorID(int test) {
		

		

		try{
			PreparedStatement prepareStatement = conn.prepareStatement("DELETE from ccdtye Where Ubicacion ="+test);
			//get connection

			//create statement
			int i = prepareStatement.executeUpdate();
			System.out.println(i);
			
			


			//close connection
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public void modificar(CCDTyE Centro, int test) {
		String url = "jdbc:mysql://localhost:3306/tpfinal";
		String usuario = "root";
		String contrasenia = "admin";

		try {
			conn = DriverManager.getConnection(url, usuario, contrasenia);
			PreparedStatement prepareStatement = conn.prepareStatement("UPDATE `ccdtye` SET `Ubicacion`= ?, `Nombre_ccdtye`= ?,`Fecha_Apertura` = ?.`Fecha_Cierre` = ? WHERE Ubicacion ="+ test);
			prepareStatement.setInt(1,Centro.getUbicacion() );
			prepareStatement.setString(2,Centro.getNombre());
			prepareStatement.setDate(3, Centro.getFechaMarcha());
			prepareStatement.setDate(4, Centro.getFechaCierre());

			int i = prepareStatement.executeUpdate();
			System.out.println(i);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("No pude");
			e.printStackTrace();
		}
	}

}
