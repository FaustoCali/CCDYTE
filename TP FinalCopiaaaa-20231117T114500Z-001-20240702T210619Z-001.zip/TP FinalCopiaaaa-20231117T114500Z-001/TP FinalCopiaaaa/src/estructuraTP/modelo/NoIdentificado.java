package estructuraTP.modelo;

import java.sql.Date;
import java.time.LocalDate;

public class NoIdentificado{
	private String Apodo;
	private String Descripcion;
	private int TestidoDni;
	private int IDNoID;
	
	
	public NoIdentificado(String apodo, String descripcion, int testidoDni, int IDID) {
		super();
		Apodo = apodo;
		Descripcion = descripcion;
		TestidoDni = testidoDni;
		IDNoID = IDID;
	}
	
	public int getIDNoID() {
		return IDNoID;
	}

	public void setIDNoID(int iDNoID) {
		IDNoID = iDNoID;
	}

	public String getApodo() {
		return Apodo;
	}
	public void setApodo(String apodo) {
		Apodo = apodo;
	}
	public String getDescripcion() {
		return Descripcion;
	}
	public void setDescripcion(String descripcion) {
		Descripcion = descripcion;
	}
	public int getTestidoDni() {
		return TestidoDni;
	}
	public void setTestidoDni(int testidoDni) {
		TestidoDni = testidoDni;
	}
	

}
