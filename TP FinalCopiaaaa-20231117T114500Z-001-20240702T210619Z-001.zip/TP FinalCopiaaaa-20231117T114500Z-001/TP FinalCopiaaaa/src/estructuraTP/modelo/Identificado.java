package estructuraTP.modelo;

import java.sql.Date;
import java.time.LocalDate;

public class Identificado{
	private int DNI_identificado;
	private String Nombre_Completo_Identificado;
	private int Lugar_Secuestro;
	private LocalDate Fecha_Ultimo_Avistamiento;
	private String Biografia_Personal;
	private String MaterialAV;
	private int DNI_TestigoFK;
	
	
	public Identificado(int dNI_identificado, String nombre_Completo_Identificado, int lugar_Secuestro,
			LocalDate fecha_Ultimo_Avistamiento, String biografia_Personal, String materialAV, int dNI_TestigoFK) {
		super();
		DNI_identificado = dNI_identificado;
		Nombre_Completo_Identificado = nombre_Completo_Identificado;
		Lugar_Secuestro = lugar_Secuestro;
		Fecha_Ultimo_Avistamiento = fecha_Ultimo_Avistamiento;
		Biografia_Personal = biografia_Personal;
		MaterialAV = materialAV;
		DNI_TestigoFK = dNI_TestigoFK;
	}



	public String getBiografia_Personal() {
		return Biografia_Personal;
	}
	public void setBiografia_Personal(String biografia_Personal) {
		Biografia_Personal = biografia_Personal;
	}
	public String getMaterialAV() {
		return MaterialAV;
	}
	public void setMaterialAV(String materialAV) {
		MaterialAV = materialAV;
	}
	public int getDNI_identificado() {
		return DNI_identificado;
	}
	public void setDNI_identificado(int dNI_identificado) {
		DNI_identificado = dNI_identificado;
	}
	public String getNombre_Completo_Identificado() {
		return Nombre_Completo_Identificado;
	}
	public void setNombre_Completo_Identificado(String nombre_Completo_Identificado) {
		Nombre_Completo_Identificado = nombre_Completo_Identificado;
	}
	public int getLugar_Secuestro() {
		return Lugar_Secuestro;
	}
	public void setLugar_Secuestro(int lugar_Secuestro) {
		Lugar_Secuestro = lugar_Secuestro;
	}
	public LocalDate getFecha_Ultimo_Avistamiento() {
		return Fecha_Ultimo_Avistamiento;
	}
	public void setFecha_Ultimo_Avistamiento(LocalDate fecha_Ultimo_Avistamiento) {
		Fecha_Ultimo_Avistamiento = fecha_Ultimo_Avistamiento;
	}
	public int getDNI_TestigoFK() {
		return DNI_TestigoFK;
	}
	public void setDNI_TestigoFK(int dNI_TestigoFK) {
		DNI_TestigoFK = dNI_TestigoFK;
	}

}
