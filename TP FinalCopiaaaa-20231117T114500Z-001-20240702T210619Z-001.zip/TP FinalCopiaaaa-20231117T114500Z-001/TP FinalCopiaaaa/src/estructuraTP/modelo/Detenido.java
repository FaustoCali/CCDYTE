package estructuraTP.modelo;

import java.sql.Date;
import java.time.LocalDate;

public abstract class Detenido {
	private int DNIDetenido;
	private String NombreDetenido;
	//private String ApellidoDetenido;
	private int LugarSecuestro;
	private LocalDate UlVisto;
	

	public Detenido(int dNIDetenido2, String nombreDetenido2, int lugarSecuestro2,
			LocalDate ulVisto2) {
		// TODO Auto-generated constructor stub
	}
	public int getDNIDetenido() {
		return DNIDetenido;
	}
	public void setDNIDetenido(int dNIDetenido) {
		DNIDetenido = dNIDetenido;
	}
	public String getNombreDetenido() {
		return NombreDetenido;
	}
	public void setNombreDetenido(String nombreDetenido) {
		NombreDetenido = nombreDetenido;
	}
	public int getLugarSecuestro() {
		return LugarSecuestro;
	}
	public void setLugarSecuestro(int lugarSecuestro) {
		LugarSecuestro = lugarSecuestro;
	}
	public LocalDate getUlVisto() {
		return UlVisto;
	}
	public void setUlVisto(LocalDate ulVisto) {
		UlVisto = ulVisto;
	}

}
