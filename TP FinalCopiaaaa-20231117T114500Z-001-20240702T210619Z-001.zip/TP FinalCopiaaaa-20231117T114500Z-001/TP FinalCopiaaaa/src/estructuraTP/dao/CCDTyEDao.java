package estructuraTP.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import estructuraTP.modelo.CCDTyE;

public class CCDTyEDao {
	Conexion c = new Conexion();
	Connection conn = c.getConn();
	
	public void guardar(CCDTyE Centro) {
		
		
		try {
			c.ConexionBD();
			PreparedStatement prepareStatement = c.getConn().prepareStatement("INSERT INTO `ccdtye` (`Ubicacion`, `Nombre_ccdtye`,`Fecha_Apertura`,`Fecha_Cierre`) VALUES (?, ?,?,?)");
			prepareStatement.setInt(1,Centro.getUbicacion() );
			prepareStatement.setString(2,Centro.getNombre());
			Date test1 = Date.valueOf(Centro.getFechaMarcha());
			Date test2 = Date.valueOf(Centro.getFechaCierre());
			prepareStatement.setDate(3, test1);
			prepareStatement.setDate(4, test2);
			
			int i = prepareStatement.executeUpdate();
			System.out.println(i);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("No pude");
			e.printStackTrace();
		}
			
	}
	public ArrayList<CCDTyE> MostrarTodos() {
		c.ConexionBD();
		Statement statement = null;
		  ArrayList<CCDTyE> Test = new ArrayList<>();
		String query = "select Ubicacion, Nombre_ccdtye,Fecha_Apertura,Fecha_Cierre from ccdtye";

 
		try{			
			//get connection
			FuerzaDao Fdao = new FuerzaDao();
 
			//create statement
			statement = c.getConn().createStatement();
			 
			//execute query
			ResultSet rs = statement.executeQuery(query);
			while (rs.next()) {			 
			  int empId = rs.getInt("Ubicacion");
			   String empName = rs.getString("Nombre_ccdtye");
			   Date FechaOp = rs.getDate("Fecha_Apertura");
			   Date FechaCi = rs.getDate("Fecha_Cierre");
			   String[] test6 = Fdao.encontrarFuerzasPorCentro(empId);
			   CCDTyE c = new CCDTyE(empName, empId, FechaOp.toLocalDate(), FechaCi.toLocalDate(),test6);
			   
			   
			   Test.add(c);
			
			   
			   

			}
 
			//close connection
			statement.close();
		}catch(Exception e){ 
			e.printStackTrace();
		}
		return Test;
	}
	public void EliminarPorID(int test) {
		
		c.ConexionBD();
		

		try{
			
			
			PreparedStatement prepareStatement = conn.prepareStatement("DELETE from ccdtye Where Ubicacion =  "+test);
			//get connection

			//create statement
			int i = prepareStatement.executeUpdate();
			System.out.println(i);
	
			


			//close connection
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public void modificar(CCDTyE Centro, int test) {
		c.ConexionBD();

	    try {
	        PreparedStatement prepareStatement = conn.prepareStatement("UPDATE `tp_final`.`ccdtye` SET `Ubicacion`= ?, `Nombre_ccdtye`= ?,`Fecha_Apertura` = ?, `Fecha_Cierre` = ? WHERE Ubicacion ="+ test);
	        prepareStatement.setInt(1,Centro.getUbicacion() );
	        prepareStatement.setString(2,Centro.getNombre());
	        Date test1 = Date.valueOf(Centro.getFechaMarcha());
	        Date test2 = Date.valueOf(Centro.getFechaCierre());
	        prepareStatement.setDate(3,test1);
	        prepareStatement.setDate(4, test2);

	        int i = prepareStatement.executeUpdate();
	        System.out.println(i);

	    } catch (SQLException e) {
	        System.out.println("No pude");
	        e.printStackTrace();
	    }
	}


}
