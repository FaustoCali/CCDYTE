package estructuraTP.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import estructuraTP.modelo.CCDTyE;
import estructuraTP.modelo.Identificado;
import estructuraTP.modelo.NoIdentificado;

public class NoIdentificadoDao {
	Conexion c = new Conexion();
	Connection conn = c.getConn();
	
	public void guardar(NoIdentificado Id) {
		
		
		try {
			c.ConexionBD();
			PreparedStatement prepareStatement = c.getConn().prepareStatement("INSERT INTO `tpfinalcali`.`no_identificado`(`Apodo`,`Descripcion`,`DNI_Testigo`)VALUES(?,?,?);");
	        prepareStatement.setString(1,Id.getApodo());
	        prepareStatement.setString(2,Id.getDescripcion());
	        prepareStatement.setInt(6,Id.getTestidoDni());
			
			int i = prepareStatement.executeUpdate();
			System.out.println(i);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("No pude");
			e.printStackTrace();
		}
			
	}
	public ArrayList<NoIdentificado> MostrarTodos() {
		c.ConexionBD();
		Statement statement = null;
		NoIdentificadoDao Tilin = new NoIdentificadoDao();
		  ArrayList<NoIdentificado> Test = new ArrayList<NoIdentificado>();
		String query = "select * from no_identificado";

 
		try{			
			//get connection
			
 
			//create statement
			statement = c.getConn().createStatement();
			 
			//execute query
			ResultSet rs = statement.executeQuery(query);
			while (rs.next()) {			 
			  String empId = rs.getString("Apodo");
			   String empName = rs.getString("Descripcion");
			  int FechaOp = rs.getInt("DNI_Testigo");
			   NoIdentificado c = new NoIdentificado( empId, empName,FechaOp,Tilin.obtenerProximoId());
			   
			   
			   Test.add(c);
			
			   
			   

			}
 
			//close connection
			statement.close();
		}catch(Exception e){ 
			e.printStackTrace();
		}
		return Test;
	}
	public void EliminarPorID(int test) {
		
		c.ConexionBD();
		

		try{
			
			
			PreparedStatement prepareStatement = conn.prepareStatement("DELETE from no_identificado Where IDno_identificado =  "+test);
			//get connection

			//create statement
			int i = prepareStatement.executeUpdate();
			System.out.println(i);
	
			


			//close connection
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public void modificar(NoIdentificado Id, String nombre) {
		c.ConexionBD();

	    try {
	        PreparedStatement prepareStatement = conn.prepareStatement("UPDATE `tp_final`.`no_identificado` SET `Apodo`= ?, `Descripcion`= ?,`IDno_identificado` = ?, `DNI_Testigo` = ?  WHERE Apodo ="+ nombre);
	        prepareStatement.setString(1,Id.getApodo());
	        prepareStatement.setString(2,Id.getDescripcion());
	        prepareStatement.setInt(3,Id.getIDNoID());
	        prepareStatement.setInt(4,Id.getTestidoDni());

	        int i = prepareStatement.executeUpdate();
	        System.out.println(i);

	    } catch (SQLException e) {
	        System.out.println("No pude");
	        e.printStackTrace();
	    }
	}
	public int obtenerProximoId() {
		c.ConexionBD();
        Statement statement = null;
        ResultSet resultSet = null;

        try {

            // Consulta para obtener el próximo ID autoincremental
            String query = "SELECT AUTO_INCREMENT FROM information_schema.TABLES WHERE TABLE_SCHEMA = 'tp_final' AND TABLE_NAME = 'no_identificado'";
            
            statement = conn.createStatement();
            resultSet = statement.executeQuery(query);

            if (resultSet.next()) {
                return resultSet.getInt("AUTO_INCREMENT");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Cerrar recursos (resultSet, statement, connection) en el bloque finally
        }

        // Manejo de errores o valor por defecto si algo sale mal
        return -1;
    }


}
