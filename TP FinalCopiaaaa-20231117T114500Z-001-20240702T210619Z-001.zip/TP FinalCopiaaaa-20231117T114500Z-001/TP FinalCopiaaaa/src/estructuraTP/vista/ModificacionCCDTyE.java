package estructuraTP.vista;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import estructuraTP.dao.CCDTyEDao;
import estructuraTP.dao.FuerzaDao;
import estructuraTP.modelo.CCDTyE;

public class ModificacionCCDTyE extends JPanel {

    private JTextField txtNombre;
    private JTextField txtUbicacion;
    private JTextField txtFechaApertura;
    private JTextField txtFechaCierre;
    private JPanel panelFuerzas;
    private CCDTyE centroElegido;

    public ModificacionCCDTyE() {
        setLayout(null);

        JLabel lblNombre = new JLabel("Nombre");
        lblNombre.setBounds(25, 25, 46, 14);
        add(lblNombre);

        txtNombre = new JTextField();
        txtNombre.setBounds(81, 22, 150, 20);
        add(txtNombre);

        JLabel lblUbicacion = new JLabel("Ubicacion a modificar");
        lblUbicacion.setBounds(25, 75, 150, 14);
        add(lblUbicacion);

        txtUbicacion = new JTextField();
        txtUbicacion.setBounds(181, 72, 50, 20);
        add(txtUbicacion);

        JLabel lblFecha1 = new JLabel("Fecha Apertura");
        lblFecha1.setBounds(25, 125, 150, 14);
        add(lblFecha1);

        txtFechaApertura = new JTextField();
        txtFechaApertura.setBounds(181, 122, 150, 20);
        add(txtFechaApertura);

        JLabel lblFecha2 = new JLabel("Fecha Cierre");
        lblFecha2.setBounds(25, 175, 150, 14);
        add(lblFecha2);

        txtFechaCierre = new JTextField();
        txtFechaCierre.setBounds(181, 172, 150, 20);
        add(txtFechaCierre);

        JLabel lblFuerzas = new JLabel("Fuerzas");
        lblFuerzas.setBounds(25, 225, 150, 14);
        add(lblFuerzas);
        
        panelFuerzas = new JPanel();
        panelFuerzas.setBounds(181, 222, 150, 60);  // Ajustar según sea necesario
        add(panelFuerzas);

        JButton btnGuardar = new JButton("Modifica la ubicacion que pongas");
        btnGuardar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String nombre = txtNombre.getText();
                int ubicacion = Integer.parseInt(txtUbicacion.getText());
                LocalDate fechaApertura = LocalDate.parse(txtFechaApertura.getText());
                LocalDate fechaCierre = LocalDate.parse(txtFechaCierre.getText());
                String[] fuerzas = obtenerFuerzasSeleccionadas();

                CCDTyE centro = new CCDTyE(nombre, ubicacion, fechaApertura, fechaCierre, fuerzas);

                CCDTyEDao ccdTyEDao = new CCDTyEDao();
                FuerzaDao fuerzaDao = new FuerzaDao();

                if (centroElegido == null) {
                    ccdTyEDao.guardar(centro);
                    fuerzaDao.relacionarFuerzas(fuerzas, ubicacion);
                } else {
                    ccdTyEDao.modificar(centro, ubicacion);
                    fuerzaDao.eliminarFuerzas(ubicacion);
                    fuerzaDao.relacionarFuerzas(fuerzas, ubicacion);
                }
            }
        });
        btnGuardar.setBounds(78, 295, 250, 23);
        add(btnGuardar);

        JButton btnVolver = new JButton("Volver");
        btnVolver.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFrame frame = (JFrame) SwingUtilities.getWindowAncestor((Component) e.getSource());
                frame.setContentPane(new MostrarCCDTyE());
                frame.validate();
            }
        });
        btnVolver.setBounds(351, 266, 89, 23);
        add(btnVolver);

        cargarFuerzasEnCheckBoxes();  
    }

    public ModificacionCCDTyE(CCDTyE centroElegido) {
        this();
        this.centroElegido = centroElegido;
        if (centroElegido != null) {
            txtNombre.setText(centroElegido.getNombre());
            txtUbicacion.setText(String.valueOf(centroElegido.getUbicacion()));
            txtFechaApertura.setText(centroElegido.getFechaMarcha().toString());
            txtFechaCierre.setText(centroElegido.getFechaCierre().toString());

        }
    }

    private void cargarFuerzasEnCheckBoxes() {
        // Descomentar y modificar según tus necesidades
        String[] todasLasFuerzas = {"policia","ejercito","gendarmeria"};

        // Eliminar elementos anteriores
        panelFuerzas.removeAll();

        // Crear checkboxes y agregar al panel
        for (String fuerza : todasLasFuerzas) {
            JCheckBox checkBox = new JCheckBox(fuerza);
            panelFuerzas.add(checkBox);
        }

        // Refrescar la interfaz
        panelFuerzas.revalidate();
        panelFuerzas.repaint();
    }

    private String[] obtenerFuerzasSeleccionadas() {
        Component[] components = panelFuerzas.getComponents();
        List<String> fuerzasSeleccionadas = new ArrayList<>();

        for (Component component : components) {
            if (component instanceof JCheckBox) {
                JCheckBox checkBox = (JCheckBox) component;
                if (checkBox.isSelected()) {
                    fuerzasSeleccionadas.add(checkBox.getText());
                }
            }
        }

        return fuerzasSeleccionadas.toArray(new String[0]);
    }
}

