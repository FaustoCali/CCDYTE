package estructuraTP.vista;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import estructuraTP.dao.CCDTyEDao;
import estructuraTP.dao.CCDTyE_IdentificadoDao;
import estructuraTP.dao.CCDTyE_NoIdentificadoDao;
import estructuraTP.dao.FuerzaDao;
import estructuraTP.dao.IdentificadoDao;
import estructuraTP.dao.NoIdentificadoDao;
import estructuraTP.dao.TestigoDao;
import estructuraTP.modelo.CCDTyE;
import estructuraTP.modelo.Identificado;
import estructuraTP.modelo.NoIdentificado;
import estructuraTP.modelo.Testigo;

public class ModificacionNoIdentificados extends JPanel {

    private JTextField txtNombre;
    private JTextField txtLugar;
    private JTextField txtCentro;
    private JTextField txtTestigo;
    private NoIdentificado DetenidoElegido;


    public ModificacionNoIdentificados() {
        setLayout(null);

        JLabel lblNombre = new JLabel("Nombre");
        lblNombre.setBounds(25, 25, 46, 14);
        add(lblNombre);

        txtNombre = new JTextField();
        txtNombre.setBounds(81, 22, 150, 20);
        add(txtNombre);

        JLabel lblTestimonio = new JLabel("Descripcion");
        lblTestimonio.setBounds(25, 75, 150, 14);
        add(lblTestimonio);

        txtLugar = new JTextField();
        txtLugar.setBounds(181, 72, 50, 20);
        add(txtLugar);
        
        JLabel lblCentro = new JLabel("Centro");
        lblCentro.setBounds(25, 75, 150, 14);
        add(lblCentro);

        txtCentro = new JTextField();
        txtCentro.setBounds(181, 72, 50, 20);
        add(txtCentro);
        
        JLabel lblTestigo = new JLabel("Testigo");
        lblTestigo.setBounds(25, 75, 150, 14);
        add(lblTestigo);

        txtTestigo = new JTextField();
        txtTestigo.setBounds(181, 72, 50, 20);
        add(txtTestigo);
        
        JButton btnGuardar = new JButton("Modifica la ubicacion que pongas");
        btnGuardar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String nombre = txtNombre.getText();
                String ubicacion = txtLugar.getText();
                int Testigo =  Integer.parseInt(txtTestigo.getText()); 

                
                NoIdentificadoDao TestD = new NoIdentificadoDao();
                CCDTyE_NoIdentificadoDao estoycansadojefe = new CCDTyE_NoIdentificadoDao();
                
                NoIdentificado Test = new NoIdentificado(nombre,ubicacion,TestD.obtenerProximoId(),Testigo);
                estoycansadojefe.realcionarCCDTyE_DDNI(Integer.parseInt(txtCentro.getText()),Test.getIDNoID());

                


                if (DetenidoElegido == null) {
                    TestD.guardar(Test);
                 
                } else {
                    TestD.modificar(Test, nombre);
                }
            }
        });
        btnGuardar.setBounds(78, 295, 250, 23);
        add(btnGuardar);

        JButton btnVolver = new JButton("Volver");
        btnVolver.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFrame frame = (JFrame) SwingUtilities.getWindowAncestor((Component) e.getSource());
                frame.setContentPane(new MostrarIdentificado());
                frame.validate();
            }
        });
        btnVolver.setBounds(351, 266, 89, 23);
        add(btnVolver);
    }

    public ModificacionNoIdentificados(NoIdentificado DetenidoElegido) {
        this();
        this.DetenidoElegido = DetenidoElegido;
        if (DetenidoElegido!= null) {
            txtNombre.setText(DetenidoElegido.getApodo());
            txtLugar.setText(String.valueOf(DetenidoElegido.getDescripcion()));
            txtTestigo.setText(String.valueOf(DetenidoElegido.getTestidoDni()));
            


        }
    }
}
