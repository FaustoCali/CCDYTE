package estructuraTP.vista;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import estructuraTP.dao.CCDTyEDao;
import estructuraTP.dao.CCDTyE_IdentificadoDao;
import estructuraTP.dao.FuerzaDao;
import estructuraTP.dao.IdentificadoDao;
import estructuraTP.dao.TestigoDao;
import estructuraTP.modelo.CCDTyE;
import estructuraTP.modelo.Identificado;
import estructuraTP.modelo.Testigo;

public class ModificacionIdentificados extends JPanel {

    private JTextField txtNombre;
    private JTextField txtLugar;
    private JTextField txtUltimoAV;
    private JTextField txtBiografia;
    private JTextField txtmaterialAV;
    private JTextField txtCentro;
    private JTextField txtCoso;
    private Identificado DetenidoElegido;

    public ModificacionIdentificados() {
        setLayout(null);

        JLabel lblNombre = new JLabel("Nombre");
        lblNombre.setBounds(25, 25, 46, 14);
        add(lblNombre);

        txtNombre = new JTextField();
        txtNombre.setBounds(81, 22, 150, 20);
        add(txtNombre);

        JLabel lblTestimonio = new JLabel("Ubicacion a modificar");
        lblTestimonio.setBounds(25, 75, 150, 14);
        add(lblTestimonio);

        txtLugar = new JTextField();
        txtLugar.setBounds(181, 72, 50, 20);
        add(txtLugar);
        
        JLabel lblUltimoAV = new JLabel("Ultimo Avistamiento");
        lblUltimoAV.setBounds(25, 75, 150, 14);
        add(lblUltimoAV);

        txtUltimoAV = new JTextField();
        txtUltimoAV.setBounds(181, 72, 50, 20);
        add(txtUltimoAV);
        
        JLabel lblBiografia = new JLabel("Biografia");
        lblBiografia.setBounds(25, 75, 150, 14);
        add(lblBiografia);

        txtBiografia = new JTextField();
        txtBiografia.setBounds(181, 72, 50, 20);
        add(txtBiografia);
        
        JLabel lblCentro = new JLabel("Centro donde va a estar ubicado");
        lblCentro.setBounds(25, 75, 150, 14);
        add(lblCentro);

        txtCentro = new JTextField();
        txtCentro.setBounds(181, 72, 50, 20);
        add(txtCentro);
        
        JLabel lblCoso = new JLabel("Testigo");
        lblCoso.setBounds(25, 75, 150, 14);
        add(lblCoso);

        txtCoso = new JTextField();
        txtCoso.setBounds(181, 72, 50, 20);
        add(txtCoso);


        JButton btnGuardar = new JButton("Modifica la ubicacion que pongas");
        btnGuardar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String nombre = txtNombre.getText();
                int ubicacion = Integer.parseInt(txtLugar.getText());
                LocalDate fechaApertura = LocalDate.parse(txtUltimoAV.getText());
                String Bio = txtBiografia.getText();
                String MaterialAv = txtmaterialAV.getText();
                int Testigo = Integer.parseInt(txtCoso.getText());
                
                IdentificadoDao TestD = new IdentificadoDao();
                CCDTyE_IdentificadoDao estoycansadojefe = new CCDTyE_IdentificadoDao();
                
                Identificado Test = new Identificado(TestD.obtenerProximoId(),nombre, ubicacion, fechaApertura, Bio, MaterialAv,Testigo);
                estoycansadojefe.realcionarCCDTyE_DDNI(Integer.parseInt(txtCentro.getText()),Test.getDNI_identificado());

                


                if (DetenidoElegido == null) {
                    TestD.guardar(Test);
                 
                } else {
                    TestD.modificar(Test, nombre);
                }
            }
        });
        btnGuardar.setBounds(78, 295, 250, 23);
        add(btnGuardar);

        JButton btnVolver = new JButton("Volver");
        btnVolver.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFrame frame = (JFrame) SwingUtilities.getWindowAncestor((Component) e.getSource());
                frame.setContentPane(new MostrarIdentificado());
                frame.validate();
            }
        });
        btnVolver.setBounds(351, 266, 89, 23);
        add(btnVolver);
    }

    public ModificacionIdentificados(Identificado DetenidoElegido ) {
        this();
        this.DetenidoElegido = DetenidoElegido;
        if (DetenidoElegido!= null) {
            txtNombre.setText(DetenidoElegido.getNombre_Completo_Identificado());
            txtLugar.setText(String.valueOf(DetenidoElegido.getLugar_Secuestro()));
            txtUltimoAV.setText(DetenidoElegido.getFecha_Ultimo_Avistamiento().toString());
            txtBiografia.setText(DetenidoElegido.getBiografia_Personal());
            txtmaterialAV.setText(DetenidoElegido.getMaterialAV());
            


        }
    }
}

